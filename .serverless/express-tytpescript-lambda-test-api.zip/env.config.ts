import dotenv from "dotenv";

dotenv.config();

const message = process.env.message;

export { message };
